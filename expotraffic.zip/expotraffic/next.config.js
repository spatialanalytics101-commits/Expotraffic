/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  poweredByHeader: false,
  compress: true,
  images: {
    formats: ['image/avif', 'image/webp'],
    remotePatterns: [
      { protocol: 'https', hostname: 'cdn.goodgallery.com' },
      { protocol: 'https', hostname: 'images.unsplash.com' },
    ],
  },
  async redirects() {
    return [
      // Legacy Squarespace URLs → new clean paths
      { source: '/headshots/expo-traffic-headshot-activation', destination: '/services/tradeshow-headshot-activation', permanent: true },
      { source: '/headshots/sko-sales-kickoff-headshots', destination: '/services/sko-sales-kickoff-headshots', permanent: true },
      { source: '/headshots/las-vegas-headshots', destination: '/las-vegas', permanent: true },
      { source: '/headshots/in-your-office', destination: '/services/corporate-headshots', permanent: true },
      { source: '/event-photography', destination: '/services/event-photography', permanent: true },
      { source: '/event-photography/booth-beauty-photography', destination: '/services/booth-beauty-photography', permanent: true },
      { source: '/food-photography', destination: '/services/food-photography', permanent: true },
      { source: '/faqs', destination: '/contact', permanent: true },
    ];
  },
  async headers() {
    return [
      {
        source: '/:path*',
        headers: [
          { key: 'X-Content-Type-Options', value: 'nosniff' },
          { key: 'X-Frame-Options', value: 'SAMEORIGIN' },
          { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
          { key: 'Permissions-Policy', value: 'camera=(), microphone=(), geolocation=()' },
        ],
      },
    ];
  },
};

module.exports = nextConfig;
