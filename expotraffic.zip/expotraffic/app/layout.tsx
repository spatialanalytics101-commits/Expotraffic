import type { Metadata, Viewport } from 'next';
import './globals.css';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { JsonLd } from '@/components/JsonLd';
import { localBusinessSchema } from '@/lib/seo';
import { SITE } from '@/lib/site';

export const metadata: Metadata = {
  metadataBase: new URL(SITE.baseUrl),
  title: {
    default: 'ExpoTraffic — Las Vegas Tradeshow Headshot Activation & Event Photography',
    template: '%s | ExpoTraffic',
  },
  description:
    'The #1 tradeshow booth traffic generator in Las Vegas. Professional headshot activation that captures 250+ qualified leads per day at CES, NAB, SEMA, MJBizCon & more.',
  keywords: [
    'tradeshow headshot booth',
    'headshot activation',
    'Las Vegas headshot photographer',
    'conference headshot booth',
    'Las Vegas event photography',
    'CES headshot photographer',
    'SKO headshots',
    'sales kickoff photography',
    'Las Vegas Convention Center photographer',
    'trade show booth traffic',
  ],
  alternates: { canonical: SITE.baseUrl },
  openGraph: {
    type: 'website',
    url: SITE.baseUrl,
    siteName: SITE.name,
    locale: 'en_US',
    title: 'ExpoTraffic — Las Vegas Tradeshow Headshot Activation',
    description: 'Generate 250+ leads per day at your tradeshow booth with professional headshots, instant delivery, and the longest lines on the expo floor.',
    images: ['/og/default.jpg'],
  },
  twitter: { card: 'summary_large_image' },
  robots: {
    index: true,
    follow: true,
    googleBot: { index: true, follow: true, 'max-image-preview': 'large', 'max-snippet': -1 },
  },
  icons: { icon: '/favicon.ico' },
  verification: {
    google: 'replace-with-your-gsc-token',
  },
};

export const viewport: Viewport = {
  themeColor: '#FAF8F3',
  width: 'device-width',
  initialScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,500;0,9..144,600;1,9..144,400;1,9..144,500&family=Inter:wght@400;500;600&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="min-h-screen bg-ink-50 text-ink-900 antialiased">
        <a
          href="#main"
          className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[100] focus:rounded focus:bg-amber-500 focus:px-4 focus:py-2 focus:text-ink-900"
        >
          Skip to main content
        </a>
        <Header />
        <main id="main">{children}</main>
        <Footer />
        <JsonLd data={localBusinessSchema()} />
      </body>
    </html>
  );
}
