import Link from 'next/link';
import { buildMetadata, breadcrumbSchema } from '@/lib/seo';
import { JsonLd } from '@/components/JsonLd';
import { Breadcrumbs, CTABand, ClientMarquee } from '@/components/UI';
import { SITE } from '@/lib/site';

export const metadata = buildMetadata({
  title: 'About ExpoTraffic — Steven Joseph Fogarty, Las Vegas Photographer',
  description:
    'About ExpoTraffic and founder Steven Joseph Fogarty. Las Vegas-based professional photographer since 2009. 20+ years of tradeshow, event, and corporate photography.',
  path: '/about',
  keywords: [
    'Steven Joseph Fogarty photographer',
    'Las Vegas headshot photographer',
    'ExpoTraffic founder',
    'Las Vegas tradeshow photographer bio',
  ],
});

export default function AboutPage() {
  const trail = [
    { name: 'Home', path: '/' },
    { name: 'About', path: '/about' },
  ];

  return (
    <>
      <JsonLd data={breadcrumbSchema(trail)} />

      <section className="bg-ink-50 pb-20 pt-16 lg:pb-32 lg:pt-20">
        <div className="mx-auto max-w-[88rem] px-6 lg:px-10">
          <Breadcrumbs trail={trail} />
          <div className="mt-10 grid gap-16 lg:grid-cols-[1.3fr_1fr] lg:gap-20">
            <div>
              <div className="text-xs uppercase tracking-[0.3em] text-amber-500">Founder</div>
              <h1 className="mt-4 font-serif text-display-xl text-ink-900">
                Steven Joseph <em className="italic text-amber-500">Fogarty</em>.
              </h1>
              <p className="mt-8 max-w-2xl text-xl leading-relaxed text-ink-700">
                Professional photographer since 2004. Based in Las Vegas since 2009. Owner of ExpoTraffic and Steven Joseph Photography — the team behind headshot activations for LinkedIn, IBM, Amazon, AWS, SAP, Dell-EMC, Pepsi, Toyota, Kia, Uber, and dozens more global brands.
              </p>
              <div className="mt-10 flex flex-wrap gap-3">
                <Link href="/contact" className="inline-flex items-center gap-2 rounded-full bg-ink-900 px-7 py-3.5 text-sm font-medium text-ink-50 hover:bg-amber-500">
                  Work with Steve <span aria-hidden="true">→</span>
                </Link>
                <a href={`tel:${SITE.phone}`} className="inline-flex items-center gap-2 rounded-full border border-ink-900/20 px-7 py-3.5 text-sm font-medium text-ink-900 hover:border-amber-500 hover:text-amber-600">
                  {SITE.phoneDisplay}
                </a>
              </div>
            </div>
            <aside>
              <div className="aspect-[4/5] overflow-hidden rounded-2xl bg-gradient-to-br from-amber-400 via-amber-600 to-ink-800 grain" />
            </aside>
          </div>
        </div>
      </section>

      <section className="py-24 md:py-32">
        <div className="mx-auto grid max-w-[88rem] gap-16 px-6 lg:grid-cols-[1fr_1.5fr] lg:px-10">
          <div className="text-xs uppercase tracking-[0.3em] text-amber-500">Story</div>
          <div className="max-w-prose-wide space-y-6 text-lg leading-relaxed text-ink-700">
            <p>
              Steve started shooting weddings in 2004. By 2009 he&rsquo;d moved to Las Vegas — the convention capital of the world — and pivoted the practice toward what he&rsquo;d discovered was a completely under-served corporate market: the tradeshow headshot activation.
            </p>
            <p>
              The insight was simple. Tradeshow exhibitors were spending hundreds of thousands of dollars on booths full of USB sticks, mousepads, and plastic giveaways — and their leads were awful. Meanwhile, every one of those attendees needed a decent LinkedIn headshot and didn&rsquo;t have one. Bridge the gap with a professional photo studio, a branded delivery system, and aggressive lead capture, and suddenly the boring tote-bag booth becomes the busiest spot at the show.
            </p>
            <p>
              Fifteen years later, that insight has turned ExpoTraffic into the Fortune 500 tradeshow industry&rsquo;s worst-kept secret. If you see a booth at CES, NAB, or AWS re:Invent with a line around the corner and a photographer running the room — there&rsquo;s a good chance it&rsquo;s one of ours.
            </p>
          </div>
        </div>
      </section>

      <section className="border-y border-ink-900/10 bg-ink-100/40 py-24">
        <div className="mx-auto max-w-[88rem] px-6 lg:px-10">
          <h2 className="font-serif text-display text-ink-900">What we&rsquo;re known for</h2>
          <div className="mt-12 grid gap-8 md:grid-cols-3">
            {[
              ['Production standard', 'Same studio-strobe rigs, color science, and retouching used by Fortune 500 comms departments.'],
              ['Show-floor logistics', 'Every union rule, every venue, every load-in window in Las Vegas — already mapped.'],
              ['Measurable ROI', 'Not a vibes business. Every engagement is instrumented with lead capture and cost-per-lead tracking.'],
            ].map(([t, d]) => (
              <div key={t} className="rounded-xl border border-ink-900/10 bg-ink-50 p-6">
                <h3 className="font-serif text-xl text-ink-900">{t}</h3>
                <p className="mt-3 text-sm text-ink-600">{d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <ClientMarquee heading="Brands Steve has worked with" />
      <CTABand
        headline="Want to work with Steve directly?"
        sub="For custom activations, SKOs, and flagship tradeshow bookings, Steve personally runs every engagement."
      />
    </>
  );
}
