import { NextResponse } from 'next/server';

export const runtime = 'nodejs';

export async function POST(request: Request) {
  const form = await request.formData();

  const payload = {
    name: form.get('name'),
    company: form.get('company'),
    email: form.get('email'),
    event: form.get('event'),
    message: form.get('message'),
    timestamp: new Date().toISOString(),
  };

  // TODO: wire to SendGrid / Resend / Postmark / SES / CRM webhook
  // Current behaviour is a no-op success — replace with your provider of choice.
  //
  // Example with Resend:
  //   await resend.emails.send({
  //     from: 'leads@expotraffic.com',
  //     to: 'steve@expotraffic.com',
  //     subject: `Quote request — ${payload.company ?? payload.name}`,
  //     text: JSON.stringify(payload, null, 2),
  //   });

  console.log('[ExpoTraffic lead]', payload);

  return NextResponse.redirect(new URL('/contact?sent=1', request.url), 303);
}
