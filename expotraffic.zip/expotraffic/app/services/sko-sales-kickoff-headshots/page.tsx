import Link from 'next/link';
import { buildMetadata, serviceSchema, faqSchema, breadcrumbSchema } from '@/lib/seo';
import { JsonLd } from '@/components/JsonLd';
import { Breadcrumbs, CTABand, FAQSection, QuickContactForm } from '@/components/UI';

export const metadata = buildMetadata({
  title: 'SKO Sales Kickoff Headshots — Las Vegas On-Site Photography',
  description:
    'Professional SKO sales kickoff headshot photography in Las Vegas. Synchronize your entire sales team\'s LinkedIn presence in a single day with consistent lighting, on-brand retouching, and instant delivery.',
  path: '/services/sko-sales-kickoff-headshots',
  keywords: [
    'SKO headshots',
    'sales kickoff photography',
    'sales kickoff headshots Las Vegas',
    'corporate team headshots Las Vegas',
    'annual meeting headshots',
    'on-site headshots corporate event',
  ],
});

const FAQS = [
  {
    q: 'How many people can you photograph during a single-day SKO?',
    a: 'Comfortably 150–200 people per photographer per day with quality retouching. For larger sales orgs we deploy 2–4 stations simultaneously to hit 400–800 people in one day. We plan slots in 4-minute windows against your agenda.',
  },
  {
    q: 'Can you match a specific brand-book look across every headshot?',
    a: 'Yes — this is the main reason HR teams hire us for SKOs. We work from your brand guidelines (background color, crop ratio, retouching style, sharpness, color temperature) so every employee\'s headshot looks cohesive on your website, LinkedIn, and sales decks.',
  },
  {
    q: 'Do you integrate with our SKO schedule?',
    a: 'We\'ll sit with your event producer and build headshot slots into the session flow: during breakfast, between keynotes, at the end of the day. Reps book via QR code so lines never form.',
  },
  {
    q: 'How fast do employees get their photo?',
    a: 'Each person receives a branded email + SMS with their retouched headshot in under 60 seconds. A final gallery with multiple selects is delivered to HR within 48 hours.',
  },
];

export default function SKOPage() {
  const trail = [
    { name: 'Home', path: '/' },
    { name: 'Services', path: '/services' },
    { name: 'SKO sales kickoff headshots', path: '/services/sko-sales-kickoff-headshots' },
  ];

  return (
    <>
      <JsonLd
        data={[
          breadcrumbSchema(trail),
          serviceSchema({
            name: 'SKO Sales Kickoff Headshots',
            description: 'On-site SKO sales kickoff headshot photography in Las Vegas. Consistent branded headshots for your entire sales team in a single day.',
            path: '/services/sko-sales-kickoff-headshots',
            priceLow: 4500,
            priceHigh: 22000,
          }),
          faqSchema(FAQS),
        ]}
      />

      <section className="bg-ink-50 pb-20 pt-16 lg:pb-32 lg:pt-20">
        <div className="mx-auto max-w-[88rem] px-6 lg:px-10">
          <Breadcrumbs trail={trail} />
          <div className="mt-10 grid gap-16 lg:grid-cols-[1.2fr_0.8fr] lg:gap-20">
            <div>
              <h1 className="font-serif text-display-xl text-ink-900">
                SKO sales kickoff <em className="italic text-amber-500">headshots</em>.
              </h1>
              <p className="mt-8 max-w-2xl text-xl leading-relaxed text-ink-700">
                Your entire sales team, on LinkedIn, looking consistent and on-brand — by the end of SKO day one. Studio-quality lighting, brand-matched retouching, 60-second delivery, and scheduling that never pulls reps away from keynotes.
              </p>
              <div className="mt-10 flex flex-wrap gap-3">
                <Link href="/contact" className="inline-flex items-center gap-2 rounded-full bg-ink-900 px-7 py-3.5 text-sm font-medium text-ink-50 hover:bg-amber-500">
                  Book your SKO <span aria-hidden="true">→</span>
                </Link>
                <Link href="/pricing" className="inline-flex items-center gap-2 rounded-full border border-ink-900/20 px-7 py-3.5 text-sm font-medium text-ink-900 hover:border-amber-500 hover:text-amber-600">
                  See pricing
                </Link>
              </div>
            </div>
            <aside>
              <div className="rounded-2xl border border-ink-900/10 bg-ink-100/40 p-8">
                <div className="text-xs uppercase tracking-[0.3em] text-amber-500">SKO quote</div>
                <div className="mt-6"><QuickContactForm compact /></div>
              </div>
            </aside>
          </div>
        </div>
      </section>

      <section className="py-24 md:py-32">
        <div className="mx-auto grid max-w-[88rem] gap-16 px-6 lg:grid-cols-[1fr_1.5fr] lg:px-10">
          <div className="text-xs uppercase tracking-[0.3em] text-amber-500">Why SKO teams hire us</div>
          <div className="max-w-prose-wide">
            <h2 className="font-serif text-display-lg text-ink-900">
              One day. One look. <em className="italic">One team</em>.
            </h2>
            <div className="mt-8 space-y-6 text-lg leading-relaxed text-ink-700">
              <p>
                Sales orgs are remote now. When your team finally comes together for SKO in Las Vegas, it&rsquo;s the only moment you&rsquo;ll have the whole roster in one room with clean faces, sharp blazers, and decent sleep behind them. That&rsquo;s the moment to lock in a year of consistent LinkedIn headshots — not three weeks later when half the team is hungover on the Strip and the other half is back home.
              </p>
              <p>
                We slot the headshot station into your SKO agenda, publish QR-code sign-ups so nobody loses a keynote, and ship the retouched images to every employee before they&rsquo;ve landed back home. Your HR team gets a clean gallery for the website. Your sales leaders get a team that looks like a team.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="border-y border-ink-900/10 bg-ink-100/40 py-24">
        <div className="mx-auto max-w-[88rem] px-6 lg:px-10">
          <h2 className="font-serif text-display text-ink-900">What&rsquo;s included</h2>
          <div className="mt-12 grid gap-8 md:grid-cols-3">
            {[
              ['Studio setup in your venue', 'Full studio-strobe lighting rig, branded backdrop, retouching station — deployed in your conference suite.'],
              ['QR-code scheduling', 'Reps book 4-minute slots around your agenda. No lines. No missed sessions.'],
              ['Brand-matched retouching', 'Color temperature, skin retouching, crop, and background matched to your brand guidelines.'],
              ['Instant delivery to each rep', 'Branded email + SMS with retouched headshot within 60 seconds. Five selects per person.'],
              ['HR-ready final gallery', 'Full gallery delivered to HR within 48 hours — organized by department, CSV name map included.'],
              ['Multiple backdrops', 'Team shot, solo headshot, casual outdoor option — covered in one session per person.'],
            ].map(([t, d]) => (
              <div key={t} className="rounded-xl border border-ink-900/10 bg-ink-50 p-6">
                <h3 className="font-serif text-xl text-ink-900">{t}</h3>
                <p className="mt-3 text-sm text-ink-600">{d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <FAQSection items={FAQS} title="SKO headshots — FAQ" />
      <CTABand
        headline="Your next SKO — the last time your team will have mismatched headshots."
        sub="Tell us your dates and team size. We'll send a production plan within 24 hours."
      />
    </>
  );
}
