import Link from 'next/link';
import { buildMetadata, serviceSchema, faqSchema, breadcrumbSchema, reviewSchema } from '@/lib/seo';
import { JsonLd } from '@/components/JsonLd';
import { Breadcrumbs, ClientMarquee, TestimonialGrid, CTABand, FAQSection, QuickContactForm } from '@/components/UI';
import { TESTIMONIALS } from '@/lib/site';

export const metadata = buildMetadata({
  title: 'Tradeshow Headshot Booth Activation — 250+ Leads Per Day',
  description:
    'The best tradeshow headshot booth activation in Las Vegas and nationwide. Professional on-site headshot lounge that generates 250+ qualified leads daily, creates the longest lines on the expo floor, and delivers measurable booth ROI.',
  path: '/services/tradeshow-headshot-activation',
  keywords: [
    'tradeshow headshot booth',
    'headshot activation',
    'trade show booth traffic generator',
    'tradeshow lead generation',
    'expo headshot photography',
    'headshot lounge tradeshow',
    'Las Vegas tradeshow photographer',
  ],
});

const FAQS = [
  {
    q: 'How does a tradeshow headshot activation generate leads?',
    a: 'Attendees opt-in for a free professional headshot at your booth. While they wait in line, your sales team has 10–90 minutes of unrushed conversation per prospect. We capture their full contact data (name, email, title, company, plus any custom fields you want) through a branded check-in flow. The headshot is delivered instantly via email and SMS — each one branded with your logo — keeping your company top of mind for weeks after the show.',
  },
  {
    q: 'How many headshots can you shoot per day?',
    a: 'A single-station lounge produces 30–50 high-quality headshots per hour, or roughly 250 per 8-hour tradeshow day. For anchor booths we deploy 2–4 stations in parallel, hitting 500–1,000+ per day. Every session includes coaching, retouching, and attendee selection of their favorite frame.',
  },
  {
    q: 'What do we need to provide at our booth?',
    a: 'Just a 10×10 ft footprint (we can work smaller if needed) and standard 110V power. We bring everything else: photographers, camera and studio-strobe lighting, backdrops, retouching stations, check-in iPads, and branded delivery software. We can seamlessly match your booth\'s fabric, branding, and color palette.',
  },
  {
    q: 'Can the experience be fully branded to our company?',
    a: 'Yes. The check-in form, email delivery, SMS template, photo overlay graphics, and attendee gallery are fully branded with your logo, colors, and messaging. We can also integrate a slide-show monitor cycling through attendee headshots with your branding — a powerful attention magnet for the aisle.',
  },
  {
    q: 'Do you work with sponsors and expo producers?',
    a: 'Frequently. Many of our bookings come from expo producers who then resell the headshot activation to their anchor sponsor. We provide white-label service, sponsor-ready pitch materials, and can run the activation as a sponsored lounge that drives traffic to multiple booths.',
  },
  {
    q: 'What ROI should we expect compared to traditional swag?',
    a: 'Hundreds of printed tote bags end up in hotel trash cans; a professional headshot gets used on LinkedIn for years. Clients consistently report 4× more leads than previous year-over-year swag-only booths (AWS, CrowdStrike Fal.con). Because the headshot remains in use, your brand also earns residual impressions every time the person updates their profile.',
  },
  {
    q: 'How far in advance should we book?',
    a: 'For major Las Vegas shows (CES, NAB, SEMA, MJBizCon, HIMSS, AWS re:Invent), book 6–9 months out. Shoulder-season shows usually need 90 days. SKOs and smaller user conferences can often be turned around in 30–45 days.',
  },
];

const BENEFITS = [
  {
    title: 'The longest lines on the floor',
    desc: 'Your queue is going to be so long, that you\'ll need crowd management to handle all that attention. That\'s not a problem — that\'s the product.',
  },
  {
    title: '25% more booth dwell time',
    desc: 'Independently verified: our clients see a 25% uplift in time-at-booth. That means more minutes per prospect, and more deals started on-site.',
  },
  {
    title: 'Vetted, CRM-ready lead data',
    desc: 'Every attendee that steps into the studio hands over the exact data fields you specify. Post-show CSV or direct Salesforce / HubSpot export.',
  },
  {
    title: 'Residual brand impressions',
    desc: 'When your headshot ends up on someone\'s LinkedIn for 3 years, your brand is in the corner of every video call they ever take.',
  },
  {
    title: 'Zero drop-offs, real-time delivery',
    desc: 'Attendees receive their retouched headshot via email + SMS within 60 seconds. No "we\'ll follow up after the show" — the win happens live.',
  },
  {
    title: 'Fortune 500 production standards',
    desc: 'The same studio-strobe setup, color science, and retouching workflow we use for LinkedIn, IBM, Amazon, SAP, and Toyota.',
  },
];

export default function TradeshowHeadshotActivationPage() {
  const trail = [
    { name: 'Home', path: '/' },
    { name: 'Services', path: '/services' },
    { name: 'Tradeshow headshot activation', path: '/services/tradeshow-headshot-activation' },
  ];

  return (
    <>
      <JsonLd
        data={[
          breadcrumbSchema(trail),
          serviceSchema({
            name: 'Tradeshow Headshot Activation',
            description: 'Professional headshot lounge deployed inside your tradeshow booth. Generates 250+ qualified leads per day with the longest lines on the expo floor.',
            path: '/services/tradeshow-headshot-activation',
            priceLow: 8500,
            priceHigh: 45000,
          }),
          faqSchema(FAQS),
          ...reviewSchema(TESTIMONIALS.slice(0, 3).map((t) => ({ author: t.author, role: t.role, company: t.company, quote: t.quote }))),
        ]}
      />

      {/* ========== HERO ========== */}
      <section className="bg-ink-50 pb-20 pt-16 lg:pb-32 lg:pt-20">
        <div className="mx-auto max-w-[88rem] px-6 lg:px-10">
          <Breadcrumbs trail={trail} />

          <div className="mt-10 grid gap-16 lg:grid-cols-[1.2fr_0.8fr] lg:gap-20">
            <div>
              <h1 className="font-serif text-display-xl font-medium tracking-tight text-ink-900">
                Tradeshow headshot <em className="italic text-amber-500">booth</em> activation.
              </h1>
              <p className="mt-8 max-w-2xl text-xl leading-relaxed text-ink-700">
                There is no better way to generate qualified leads at your tradeshow booth than a professionally-run headshot activation from ExpoTraffic. <strong className="font-medium text-ink-900">250 attendees per day, 700+ leads over a 2.5-day show</strong>, and a line that never stops.
              </p>

              <div className="mt-10 flex flex-wrap gap-3">
                <Link
                  href="/contact"
                  className="inline-flex items-center gap-2 rounded-full bg-ink-900 px-7 py-3.5 text-sm font-medium text-ink-50 transition-all hover:bg-amber-500"
                >
                  Request a quote <span aria-hidden="true">→</span>
                </Link>
                <Link
                  href="/pricing"
                  className="inline-flex items-center gap-2 rounded-full border border-ink-900/20 px-7 py-3.5 text-sm font-medium text-ink-900 hover:border-amber-500 hover:text-amber-600"
                >
                  See pricing
                </Link>
              </div>
            </div>

            <aside className="lg:pl-8">
              <div className="rounded-2xl border border-ink-900/10 bg-ink-100/40 p-8">
                <div className="text-xs uppercase tracking-[0.3em] text-amber-500">Quick quote</div>
                <p className="mt-3 text-sm text-ink-600">Tell us about your show. We&rsquo;ll reply within one business day.</p>
                <div className="mt-6">
                  <QuickContactForm compact />
                </div>
              </div>
            </aside>
          </div>
        </div>
      </section>

      {/* ========== PROOF STAT BAND ========== */}
      <section className="border-y border-ink-900/10 bg-ink-900 text-ink-50">
        <div className="mx-auto grid max-w-[88rem] grid-cols-2 divide-x divide-ink-700 md:grid-cols-4">
          {[
            ['250+', 'leads/day'],
            ['4×', 'YoY leads (AWS)'],
            ['25%', 'dwell-time lift'],
            ['60s', 'image delivery'],
          ].map(([v, l]) => (
            <div key={l} className="px-6 py-10 text-center md:px-10 md:py-14">
              <div className="font-serif text-5xl text-amber-400 md:text-6xl">{v}</div>
              <div className="mt-2 text-xs uppercase tracking-[0.2em] text-ink-300">{l}</div>
            </div>
          ))}
        </div>
      </section>

      {/* ========== WHAT IT IS ========== */}
      <section className="py-24 md:py-32">
        <div className="mx-auto max-w-[88rem] px-6 lg:px-10">
          <div className="grid gap-16 lg:grid-cols-[1fr_1.5fr]">
            <div>
              <div className="sticky top-28 text-xs uppercase tracking-[0.3em] text-amber-500">
                What a headshot activation actually is
              </div>
            </div>
            <div className="max-w-prose-wide">
              <h2 className="font-serif text-display-lg text-ink-900">
                A fully-branded photo studio <em className="italic">inside</em> your booth — built to make it the busiest spot at the show.
              </h2>
              <div className="mt-8 space-y-6 text-lg leading-relaxed text-ink-700">
                <p>
                  A tradeshow headshot activation is a professionally-lit, branded studio that we deploy directly inside your booth footprint. Our team of headshot specialists shoots each attendee in under two minutes, delivers a retouched image to their phone and inbox within 60 seconds, and captures their full lead data through a branded check-in flow.
                </p>
                <p>
                  Most booth activations chase attention. A headshot lounge <strong className="font-medium text-ink-900">earns it</strong>. Attendees will wait 30–90 minutes in your line because a professional headshot is something they actually want — and will keep using for years. That wait time is the product. It&rsquo;s the conversation runway your sales team has been asking for.
                </p>
                <p>
                  We&rsquo;ve run this exact playbook at Fal.con for CrowdStrike (AWS), re:Invent, AWS Summit, and dozens more. The common result: the headshot booth is the talk of the show, and lead goals are smashed.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <ClientMarquee heading="Brands who&rsquo;ve made this their secret weapon" />

      {/* ========== BENEFITS GRID ========== */}
      <section className="py-24 md:py-32">
        <div className="mx-auto max-w-[88rem] px-6 lg:px-10">
          <div className="mb-16 max-w-2xl">
            <div className="text-xs uppercase tracking-[0.3em] text-amber-500">Why it works</div>
            <h2 className="mt-4 font-serif text-display-lg text-ink-900">
              Everything your booth was supposed to do — <em className="italic">finally</em> working.
            </h2>
          </div>
          <div className="grid gap-px border-y border-ink-900/10 bg-ink-900/10 md:grid-cols-2 lg:grid-cols-3">
            {BENEFITS.map((b) => (
              <div key={b.title} className="bg-ink-50 p-8 md:p-10">
                <h3 className="font-serif text-2xl text-ink-900">{b.title}</h3>
                <p className="mt-4 text-ink-600">{b.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ========== HOW IT WORKS DETAILED ========== */}
      <section className="border-t border-ink-900/10 bg-ink-100/40 py-24 md:py-32">
        <div className="mx-auto max-w-[88rem] px-6 lg:px-10">
          <div className="mb-16 max-w-2xl">
            <div className="text-xs uppercase tracking-[0.3em] text-amber-500">Process</div>
            <h2 className="mt-4 font-serif text-display-lg text-ink-900">
              From contract to CRM — how a Las Vegas headshot activation runs.
            </h2>
          </div>

          <ol className="space-y-px border-y border-ink-900/10 bg-ink-900/10">
            {[
              {
                n: '01',
                t: 'Pre-show scoping',
                d: 'We walk through your booth design, show schedule, brand guidelines, and lead-capture fields. We spec stations, photographers, and retouchers.',
                span: 'Weeks 1–2',
              },
              {
                n: '02',
                t: 'Branded asset build',
                d: 'Custom overlay graphics, check-in form, email template, SMS template, and attendee gallery — all built to your brand standards.',
                span: 'Weeks 3–4',
              },
              {
                n: '03',
                t: 'Load-in & setup',
                d: 'We load in during your booth\'s setup window. 2-hour studio setup: lighting, backdrops, computers, retouching stations, check-in iPads.',
                span: 'Show day −1',
              },
              {
                n: '04',
                t: 'On-site activation',
                d: 'A-team photographers shoot every attendee. Your sales reps stand in the line, not behind a counter. Conversations happen organically.',
                span: 'Show days',
              },
              {
                n: '05',
                t: 'Real-time delivery',
                d: 'Each retouched headshot hits the attendee\'s inbox and phone within 60 seconds — branded with your logo and messaging.',
                span: 'Live',
              },
              {
                n: '06',
                t: 'Post-show export',
                d: 'Complete lead data as CSV or direct CRM sync. Measurable cost-per-lead. Recap report with image gallery for stakeholders.',
                span: 'Week after',
              },
            ].map((s) => (
              <li key={s.n} className="grid items-start gap-4 bg-ink-50 p-8 md:grid-cols-[100px_120px_1fr] md:p-10">
                <div className="font-serif text-3xl text-amber-500">{s.n}</div>
                <div className="text-xs uppercase tracking-[0.2em] text-ink-500">{s.span}</div>
                <div>
                  <h3 className="font-serif text-2xl text-ink-900">{s.t}</h3>
                  <p className="mt-3 text-ink-600">{s.d}</p>
                </div>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <TestimonialGrid limit={3} />

      {/* ========== RELATED SERVICES ========== */}
      <section className="py-24 md:py-32">
        <div className="mx-auto max-w-[88rem] px-6 lg:px-10">
          <h2 className="font-serif text-display text-ink-900">Related services</h2>
          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {[
              ['Conference headshot booth', '/services/conference-headshot-booth', 'For associations, medical, legal, and tech conferences.'],
              ['SKO sales kickoff headshots', '/services/sko-sales-kickoff-headshots', 'Synchronize your sales team\'s LinkedIn in one session.'],
              ['Booth beauty photography', '/services/booth-beauty-photography', 'Architectural shots of your booth for press and recaps.'],
            ].map(([name, href, desc]) => (
              <Link
                key={href}
                href={href}
                className="group rounded-2xl border border-ink-900/10 p-6 hover:border-amber-500/50"
              >
                <h3 className="font-serif text-xl text-ink-900 group-hover:text-amber-600">{name}</h3>
                <p className="mt-2 text-sm text-ink-600">{desc}</p>
                <div className="mt-4 text-xs text-ink-400 group-hover:text-amber-500">Read more →</div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <FAQSection items={FAQS} title="Tradeshow headshot activation — FAQ" />
      <CTABand
        headline="Book the busiest booth at your next show."
        sub="Every CES, NAB, SEMA, and MJBizCon slot books 6+ months out. Tell us your show and we'll check availability."
      />
    </>
  );
}
