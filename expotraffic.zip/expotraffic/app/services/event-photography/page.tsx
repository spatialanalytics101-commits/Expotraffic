import Link from 'next/link';
import { buildMetadata, serviceSchema, faqSchema, breadcrumbSchema } from '@/lib/seo';
import { JsonLd } from '@/components/JsonLd';
import { Breadcrumbs, CTABand, FAQSection, ClientMarquee } from '@/components/UI';

export const metadata = buildMetadata({
  title: 'Las Vegas Event Photography — Conventions, Conferences, Corporate',
  description:
    'Full-service Las Vegas event photography for conventions, conferences, corporate galas, and brand activations. Near real-time editing and delivery to marketing teams and partners.',
  path: '/services/event-photography',
  keywords: [
    'Las Vegas event photography',
    'Las Vegas convention photographer',
    'corporate event photographer Las Vegas',
    'conference photographer Las Vegas',
    'event photography services',
    'convention photographer',
  ],
});

const FAQS = [
  {
    q: 'What types of events do you cover?',
    a: 'Conventions, tradeshows, user conferences, SKOs, product launches, corporate galas, keynotes, award ceremonies, and brand activations. We staff events from 100 attendees to 50,000+.',
  },
  {
    q: 'How fast do we get images back?',
    a: 'Selected hero shots are edited and delivered in near real-time throughout the event — typically within 2 hours — so your social media team can post while the session is still hot. Full galleries are delivered within 48 hours.',
  },
  {
    q: 'Can you work with our PR and marketing teams on-site?',
    a: 'Yes. We embed with your on-site comms team, shoot to a shot list you help build, and provide an on-site editor who pushes images to your Dropbox or Brandfolder as they happen.',
  },
  {
    q: 'Do you coordinate with the tradeshow headshot activation?',
    a: 'Absolutely — many clients book both. Our event photography team covers keynotes and networking while the headshot team runs the booth activation. Single producer, single invoice, zero coordination overhead.',
  },
];

export default function EventPhotographyPage() {
  const trail = [
    { name: 'Home', path: '/' },
    { name: 'Services', path: '/services' },
    { name: 'Event photography', path: '/services/event-photography' },
  ];

  return (
    <>
      <JsonLd
        data={[
          breadcrumbSchema(trail),
          serviceSchema({
            name: 'Las Vegas Event Photography',
            description: 'Full-service event photography for conventions, conferences, and corporate galas in Las Vegas with near real-time delivery.',
            path: '/services/event-photography',
            priceLow: 3500,
            priceHigh: 35000,
          }),
          faqSchema(FAQS),
        ]}
      />

      <section className="bg-ink-50 pb-20 pt-16 lg:pb-32 lg:pt-20">
        <div className="mx-auto max-w-[88rem] px-6 lg:px-10">
          <Breadcrumbs trail={trail} />
          <div className="mt-10 grid gap-16 lg:grid-cols-[1.2fr_0.8fr]">
            <div>
              <h1 className="font-serif text-display-xl text-ink-900">
                Las Vegas <em className="italic text-amber-500">event</em> photography.
              </h1>
              <p className="mt-8 max-w-2xl text-xl leading-relaxed text-ink-700">
                Full-convention coverage. Keynotes, breakouts, activations, networking, galas, booth beauty shots — all captured at Fortune 500 production quality and delivered to your marketing team before the session ends.
              </p>
              <div className="mt-10 flex flex-wrap gap-3">
                <Link href="/contact" className="inline-flex items-center gap-2 rounded-full bg-ink-900 px-7 py-3.5 text-sm font-medium text-ink-50 hover:bg-amber-500">
                  Get a quote <span aria-hidden="true">→</span>
                </Link>
                <Link href="/portfolio" className="inline-flex items-center gap-2 rounded-full border border-ink-900/20 px-7 py-3.5 text-sm font-medium text-ink-900 hover:border-amber-500 hover:text-amber-600">
                  See work
                </Link>
              </div>
            </div>
            <aside className="aspect-[4/5] overflow-hidden rounded-2xl bg-gradient-to-br from-ink-700 to-ink-900 grain" />
          </div>
        </div>
      </section>

      <section className="py-24 md:py-32">
        <div className="mx-auto max-w-[88rem] px-6 lg:px-10">
          <div className="mb-16 max-w-2xl">
            <div className="text-xs uppercase tracking-[0.3em] text-amber-500">Coverage types</div>
            <h2 className="mt-4 font-serif text-display-lg text-ink-900">
              Every angle of your event, <em className="italic">shot the right way</em>.
            </h2>
          </div>
          <div className="grid gap-px border-y border-ink-900/10 bg-ink-900/10 md:grid-cols-2 lg:grid-cols-3">
            {[
              ['Keynote stage photography', 'Wide establishing shots, speaker portraits, audience reaction, sponsor logo visibility.'],
              ['Breakout sessions', 'Discreet coverage of panels, fireside chats, and workshops without flash disruption.'],
              ['Networking & receptions', 'Candid, editorial-style shots of attendees engaging — not posed group grins.'],
              ['Booth & activation', 'Architectural booth beauty, crowd dynamics, sponsor logo activations.'],
              ['VIP & green room', 'Behind-the-scenes access for executive recap reels and post-event content.'],
              ['Galas & award ceremonies', 'Low-light, high-drama event photography with same-day selects for press.'],
            ].map(([t, d]) => (
              <div key={t} className="bg-ink-50 p-8">
                <h3 className="font-serif text-2xl text-ink-900">{t}</h3>
                <p className="mt-3 text-ink-600">{d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <ClientMarquee heading="Trusted at major conventions" />
      <FAQSection items={FAQS} title="Event photography — FAQ" />
      <CTABand headline="Give your marketing team images they can post the same day." />
    </>
  );
}
