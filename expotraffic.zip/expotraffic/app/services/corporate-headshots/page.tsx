import Link from 'next/link';
import { buildMetadata, serviceSchema, faqSchema, breadcrumbSchema } from '@/lib/seo';
import { JsonLd } from '@/components/JsonLd';
import { Breadcrumbs, CTABand, FAQSection } from '@/components/UI';

export const metadata = buildMetadata({
  title: 'Corporate Headshots Las Vegas — Executive & Team Photography',
  description:
    'Professional corporate headshots in Las Vegas. Executive portraits, team headshots, and LinkedIn photography — on-location in your office or at your event with studio-quality lighting.',
  path: '/services/corporate-headshots',
  keywords: [
    'corporate headshots Las Vegas',
    'Las Vegas headshot photographer',
    'executive headshots Las Vegas',
    'team headshots Las Vegas',
    'LinkedIn headshots Las Vegas',
    'in-office headshots',
  ],
});

const FAQS = [
  {
    q: 'Do you come to our office?',
    a: 'Yes. We bring the full studio to you — strobe lighting, backdrop, retouching station — anywhere in Las Vegas or greater Nevada. Zero disruption to your workday.',
  },
  {
    q: 'High-key or low-key background?',
    a: 'Both options available. High-key (white/bright) reads modern and works beautifully on LinkedIn and company bio pages. Low-key (dark/editorial) reads executive and pairs with annual reports or press features. Many teams shoot both in one session.',
  },
  {
    q: 'How long does each person take?',
    a: 'Four to eight minutes per person, including coaching. A team of 30 fits comfortably into a half-day session.',
  },
  {
    q: 'Will every headshot look consistent?',
    a: 'That\'s the whole point. We lock our lighting, color science, and retouching workflow before the first shutter click so every team member looks like part of the same company — even if you shoot over multiple days or locations.',
  },
];

export default function CorporateHeadshotsPage() {
  const trail = [
    { name: 'Home', path: '/' },
    { name: 'Services', path: '/services' },
    { name: 'Corporate headshots', path: '/services/corporate-headshots' },
  ];

  return (
    <>
      <JsonLd
        data={[
          breadcrumbSchema(trail),
          serviceSchema({
            name: 'Corporate Headshots Las Vegas',
            description: 'Professional corporate headshot photography in Las Vegas — executive, team, and employee headshots at your office or event.',
            path: '/services/corporate-headshots',
            priceLow: 450,
            priceHigh: 8500,
          }),
          faqSchema(FAQS),
        ]}
      />

      <section className="bg-ink-50 pb-20 pt-16 lg:pb-32 lg:pt-20">
        <div className="mx-auto max-w-[88rem] px-6 lg:px-10">
          <Breadcrumbs trail={trail} />
          <div className="mt-10 grid gap-16 lg:grid-cols-[1.2fr_0.8fr]">
            <div>
              <h1 className="font-serif text-display-xl text-ink-900">
                Corporate headshots <em className="italic text-amber-500">Las Vegas</em>.
              </h1>
              <p className="mt-8 max-w-2xl text-xl leading-relaxed text-ink-700">
                Executive, team, and employee headshots — shot in your office or at your event with studio-quality lighting and retouching. Same standard we bring to Fortune 500 tradeshow activations, now in your conference room.
              </p>
              <div className="mt-10 flex flex-wrap gap-3">
                <Link href="/contact" className="inline-flex items-center gap-2 rounded-full bg-ink-900 px-7 py-3.5 text-sm font-medium text-ink-50 hover:bg-amber-500">
                  Book a shoot <span aria-hidden="true">→</span>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-24 md:py-32">
        <div className="mx-auto max-w-[88rem] px-6 lg:px-10">
          <div className="grid gap-px border-y border-ink-900/10 bg-ink-900/10 md:grid-cols-2 lg:grid-cols-3">
            {[
              ['High-key — modern studio white', 'Clean white-to-light-gray backdrop. Reads LinkedIn-native. The default for tech, professional services, and startups.'],
              ['Low-key — executive editorial', 'Dark, moody, premium. Pairs with annual reports, press profiles, C-suite bios, and IR pages.'],
              ['On-location environmental', 'Inside your office using your brand\'s architecture as the backdrop. Reads as authentic culture, not a studio.'],
              ['Team + group configurations', 'Synchronized team portraits that match your individual headshots in lighting and color.'],
              ['Executive sessions', 'More time per person. Multiple looks, wardrobe changes, and premium retouching for C-suite and board.'],
              ['Event + conference headshots', 'For when you have the team together at SKO or a leadership summit — see our SKO service.'],
            ].map(([t, d]) => (
              <div key={t} className="bg-ink-50 p-8">
                <h3 className="font-serif text-xl text-ink-900">{t}</h3>
                <p className="mt-3 text-sm text-ink-600">{d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <FAQSection items={FAQS} title="Corporate headshots — FAQ" />
      <CTABand headline="Studio quality. Your office. One afternoon." />
    </>
  );
}
