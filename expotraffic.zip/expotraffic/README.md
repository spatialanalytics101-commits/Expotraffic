# ExpoTraffic — Las Vegas Tradeshow Headshot Activation & Event Photography

Production-ready Next.js 14 marketing site for ExpoTraffic, built with SSR, full SEO optimization, and keyword-targeted pages based on a complete Ahrefs-informed content strategy.

## Stack

- **Next.js 14** (App Router, server components, SSR)
- **TypeScript** — strict mode
- **Tailwind CSS** — custom ink/amber design tokens
- **Fraunces + Inter** — editorial display + refined body
- **Zero client components** — every route is server-rendered for maximum SEO and performance

## What's inside

32 prerendered routes organized around keyword clusters identified in the SEO audit:

### Money pages
- `/services/tradeshow-headshot-activation` — targets *"tradeshow headshot booth"*, *"headshot activation"*, *"trade show booth traffic generator"*
- `/` (homepage) — targets *"Las Vegas headshot photographer"* + *"tradeshow headshot activation"*

### Service hub + pages (8)
- `/services` (hub)
- `/services/tradeshow-headshot-activation`
- `/services/conference-headshot-booth`
- `/services/sko-sales-kickoff-headshots`
- `/services/corporate-headshots`
- `/services/event-photography`
- `/services/booth-beauty-photography`
- `/services/food-photography`

### Las Vegas venue pages (5)
Local SEO cluster — targets *"{venue} photographer"*, *"{venue} headshots"*
- `/las-vegas` (hub)
- `/las-vegas/convention-center`
- `/las-vegas/venetian-expo`
- `/las-vegas/mandalay-bay`
- `/las-vegas/caesars-forum`

### Event-specific pages (5)
Book-6-months-out high-intent traffic
- `/events` (hub)
- `/events/ces-headshots`
- `/events/nab-show-headshots`
- `/events/sema-headshots`
- `/events/mjbizcon-headshots`

### Company pages
- `/about`, `/pricing`, `/contact`, `/portfolio`

### Blog pillar content
- `/blog` (hub)
- `/blog/ultimate-guide-tradeshow-booth-traffic` (14-min pillar)
- `/blog/what-is-headshot-activation` (9-min pillar)

### Infrastructure
- `/sitemap.xml` — dynamically generated from `app/sitemap.ts`
- `/robots.txt` — generated from `app/robots.ts`
- `/api/contact` — lead form endpoint (wire to Resend/SendGrid/CRM)
- Custom `not-found.tsx` (404 page)

## SEO features built in

Every page ships with:

- **Per-page metadata** — unique title, description, canonical URL, OpenGraph, Twitter Card, keywords
- **JSON-LD structured data** — LocalBusiness (site-wide), Service, FAQPage, BreadcrumbList, Article, AggregateRating, Review
- **Semantic HTML** — single `<h1>`, proper `<section>`/`<article>`/`<nav>`, accessible breadcrumbs
- **301 redirects** from legacy Squarespace URLs (configured in `next.config.js`)
- **Security headers** — X-Content-Type-Options, X-Frame-Options, Referrer-Policy, Permissions-Policy
- **Accessibility** — skip-to-content link, focus-visible rings, aria-labels, WCAG-compliant color contrast

## File tree

```
expotraffic/
├── app/
│   ├── layout.tsx                 # Root layout, fonts, global schema
│   ├── page.tsx                   # Homepage
│   ├── globals.css                # Tailwind + custom CSS
│   ├── not-found.tsx              # 404
│   ├── sitemap.ts                 # Dynamic sitemap
│   ├── robots.ts                  # robots.txt
│   ├── api/contact/route.ts       # Form handler
│   ├── services/                  # 7 service pages + hub
│   ├── las-vegas/                 # 4 venues + hub
│   ├── events/                    # 4 events + hub
│   ├── blog/                      # Hub + 2 pillar articles
│   ├── about/, pricing/, contact/, portfolio/
├── components/
│   ├── Header.tsx                 # Nav with dropdown
│   ├── Footer.tsx                 # Full sitemap + NAP
│   ├── JsonLd.tsx                 # Schema injector
│   └── UI.tsx                     # Breadcrumbs, TestimonialGrid, FAQ, CTA, etc.
├── lib/
│   ├── site.ts                    # SITE constants, nav, clients, testimonials
│   └── seo.ts                     # Metadata builder + schema generators
├── public/                        # Static assets (add favicon, OG images here)
├── next.config.js                 # Redirects, headers, image domains
├── tailwind.config.ts             # Custom design tokens
└── tsconfig.json
```

## Getting started

```bash
# Install
npm install

# Development
npm run dev          # http://localhost:3000

# Production build
npm run build
npm start
```

## Deploying

### Vercel (recommended)

```bash
npm i -g vercel
vercel
```

Add these environment variables in the Vercel dashboard when you wire up the contact form:
- `RESEND_API_KEY` (or your mail provider key)
- `CONTACT_TO_EMAIL` (defaults to `steve@expotraffic.com`)

### Other hosts

Any Node.js host that supports Next.js 14 server-side rendering:
- **Netlify** — with the Next.js runtime adapter
- **AWS Amplify** — native Next.js support
- **Self-hosted** — `npm run build && npm start` behind a reverse proxy

## Post-launch SEO checklist

1. **Google Search Console** — verify ownership (token placeholder is in `app/layout.tsx`), submit `sitemap.xml`
2. **Google Business Profile** — claim and optimize listing (see master plan)
3. **301 audit** — after launch, crawl with Screaming Frog to confirm legacy URLs redirect cleanly
4. **Schema validation** — test every page type at [schema.org validator](https://validator.schema.org/)
5. **Core Web Vitals** — lighthouse audit all money pages; target 95+
6. **Content calendar** — publish 2 articles/month per the 12-month topical authority plan
7. **Backlink outreach** — Exhibitor Magazine, Trade Show News Network, HARO, event agency partners

## Customization

### Site constants

All company info (phone, email, address, client list, testimonials, stats) is centralized in `lib/site.ts`. Update once and it propagates across every page, schema, and metadata tag.

### SEO helpers

`lib/seo.ts` exports `buildMetadata()` and schema generators (`localBusinessSchema`, `serviceSchema`, `faqSchema`, `breadcrumbSchema`, `articleSchema`, `reviewSchema`). Use these on any new page you add to keep SEO consistent.

### Design tokens

`tailwind.config.ts` defines the ink/amber palette and Fraunces/Inter font stack. Adjust there to rebrand globally.

### Adding a new venue or event page

Copy an existing page (e.g. `app/events/ces-headshots/page.tsx`), update:
1. `metadata` (title, description, keywords, path)
2. `JsonLd` schema (breadcrumb, service)
3. Content (H1, FAQs, shows list)
4. Add the new route to `app/sitemap.ts`

## License

© 2026 Steven Joseph Photography / ExpoTraffic. All rights reserved.

---

Built to ship. Deploy it, submit the sitemap, and start climbing Las Vegas SERPs.
