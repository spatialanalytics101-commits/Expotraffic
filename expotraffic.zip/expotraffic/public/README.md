# Place static assets here:
# - favicon.ico
# - logo.svg
# - og/default.jpg    (1200×630)
# - og/*.jpg per-page OG images
#
# This directory is served at the site root by Next.js.
