import type { Metadata } from 'next';
import { SITE } from './site';

type BuildMetadataOpts = {
  title: string;
  description: string;
  path: string;
  image?: string;
  keywords?: string[];
  type?: 'website' | 'article';
  publishedTime?: string;
  noindex?: boolean;
};

export function buildMetadata({
  title,
  description,
  path,
  image = SITE.defaultOgImage,
  keywords = [],
  type = 'website',
  publishedTime,
  noindex = false,
}: BuildMetadataOpts): Metadata {
  const url = `${SITE.baseUrl}${path}`;
  const fullTitle = title.includes(SITE.name) ? title : `${title} | ${SITE.name}`;

  return {
    title: fullTitle,
    description,
    keywords: keywords.join(', '),
    metadataBase: new URL(SITE.baseUrl),
    alternates: { canonical: url },
    robots: noindex
      ? { index: false, follow: false }
      : { index: true, follow: true, googleBot: { index: true, follow: true, 'max-image-preview': 'large', 'max-snippet': -1 } },
    openGraph: {
      type,
      url,
      title: fullTitle,
      description,
      siteName: SITE.name,
      locale: 'en_US',
      images: [{ url: image, width: 1200, height: 630, alt: title }],
      ...(publishedTime && { publishedTime }),
    },
    twitter: {
      card: 'summary_large_image',
      title: fullTitle,
      description,
      images: [image],
    },
    authors: [{ name: SITE.founder, url: SITE.baseUrl }],
    creator: SITE.founder,
    publisher: SITE.legalName,
  };
}

// ---------- JSON-LD Schema Generators ----------

export function localBusinessSchema() {
  return {
    '@context': 'https://schema.org',
    '@type': ['LocalBusiness', 'ProfessionalService'],
    '@id': `${SITE.baseUrl}/#business`,
    name: SITE.name,
    legalName: SITE.legalName,
    description: SITE.tagline,
    url: SITE.baseUrl,
    telephone: SITE.phone,
    email: SITE.email,
    priceRange: '$$$',
    image: `${SITE.baseUrl}/og/default.jpg`,
    logo: `${SITE.baseUrl}/logo.svg`,
    founder: { '@type': 'Person', name: SITE.founder },
    address: {
      '@type': 'PostalAddress',
      addressLocality: SITE.address.locality,
      addressRegion: SITE.address.region,
      postalCode: SITE.address.postalCode,
      addressCountry: SITE.address.country,
    },
    geo: {
      '@type': 'GeoCoordinates',
      latitude: SITE.geo.lat,
      longitude: SITE.geo.lng,
    },
    areaServed: [
      { '@type': 'City', name: 'Las Vegas' },
      { '@type': 'State', name: 'Nevada' },
      { '@type': 'Country', name: 'United States' },
    ],
    serviceArea: {
      '@type': 'GeoCircle',
      geoMidpoint: { '@type': 'GeoCoordinates', latitude: SITE.geo.lat, longitude: SITE.geo.lng },
      geoRadius: 5000000,
    },
    openingHoursSpecification: [{
      '@type': 'OpeningHoursSpecification',
      dayOfWeek: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
      opens: '08:00',
      closes: '20:00',
    }],
    sameAs: [SITE.social.linkedin, SITE.social.instagram],
    aggregateRating: {
      '@type': 'AggregateRating',
      ratingValue: '5.0',
      reviewCount: '47',
    },
  };
}

export function serviceSchema(opts: {
  name: string;
  description: string;
  path: string;
  priceLow?: number;
  priceHigh?: number;
}) {
  return {
    '@context': 'https://schema.org',
    '@type': 'Service',
    '@id': `${SITE.baseUrl}${opts.path}#service`,
    serviceType: opts.name,
    name: opts.name,
    description: opts.description,
    url: `${SITE.baseUrl}${opts.path}`,
    provider: { '@id': `${SITE.baseUrl}/#business` },
    areaServed: [
      { '@type': 'City', name: 'Las Vegas' },
      { '@type': 'Country', name: 'United States' },
    ],
    ...(opts.priceLow && opts.priceHigh && {
      offers: {
        '@type': 'AggregateOffer',
        priceCurrency: 'USD',
        lowPrice: opts.priceLow,
        highPrice: opts.priceHigh,
      },
    }),
  };
}

export function faqSchema(items: { q: string; a: string }[]) {
  return {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: items.map((i) => ({
      '@type': 'Question',
      name: i.q,
      acceptedAnswer: { '@type': 'Answer', text: i.a },
    })),
  };
}

export function breadcrumbSchema(trail: { name: string; path: string }[]) {
  return {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: trail.map((t, i) => ({
      '@type': 'ListItem',
      position: i + 1,
      name: t.name,
      item: `${SITE.baseUrl}${t.path}`,
    })),
  };
}

export function articleSchema(opts: {
  headline: string;
  description: string;
  path: string;
  datePublished: string;
  image?: string;
}) {
  return {
    '@context': 'https://schema.org',
    '@type': 'Article',
    headline: opts.headline,
    description: opts.description,
    image: opts.image || `${SITE.baseUrl}${SITE.defaultOgImage}`,
    datePublished: opts.datePublished,
    dateModified: opts.datePublished,
    author: { '@type': 'Person', name: SITE.founder, url: SITE.baseUrl },
    publisher: { '@id': `${SITE.baseUrl}/#business` },
    mainEntityOfPage: { '@type': 'WebPage', '@id': `${SITE.baseUrl}${opts.path}` },
  };
}

export function reviewSchema(reviews: { author: string; role: string; company: string; quote: string }[]) {
  return reviews.map((r) => ({
    '@context': 'https://schema.org',
    '@type': 'Review',
    reviewBody: r.quote,
    author: { '@type': 'Person', name: `${r.author}, ${r.role} at ${r.company}` },
    itemReviewed: { '@id': `${SITE.baseUrl}/#business` },
    reviewRating: { '@type': 'Rating', ratingValue: '5', bestRating: '5' },
  }));
}
