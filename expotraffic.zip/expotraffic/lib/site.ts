export const SITE = {
  name: 'ExpoTraffic',
  legalName: 'Steven Joseph Photography / ExpoTraffic',
  founder: 'Steven Joseph Fogarty',
  tagline: 'Las Vegas tradeshow headshot activation & event photography',
  baseUrl: 'https://www.expotraffic.com',
  phone: '+1-702-904-2972',
  phoneDisplay: '(702) 904-2972',
  email: 'steve@expotraffic.com',
  address: {
    locality: 'Las Vegas',
    region: 'NV',
    postalCode: '89145',
    country: 'US',
  },
  geo: {
    lat: 36.1699,
    lng: -115.1398,
  },
  social: {
    linkedin: 'https://www.linkedin.com/in/stevenjosephphotography',
    instagram: 'https://www.instagram.com/stevenjosephphotography',
  },
  defaultOgImage: '/og/default.jpg',
} as const;

export const NAV = {
  primary: [
    {
      label: 'Services',
      href: '/services',
      children: [
        { label: 'Tradeshow headshot activation', href: '/services/tradeshow-headshot-activation' },
        { label: 'Conference headshot booth', href: '/services/conference-headshot-booth' },
        { label: 'SKO sales kickoff headshots', href: '/services/sko-sales-kickoff-headshots' },
        { label: 'Corporate headshots', href: '/services/corporate-headshots' },
        { label: 'Event photography', href: '/services/event-photography' },
        { label: 'Booth beauty photography', href: '/services/booth-beauty-photography' },
        { label: 'Food photography', href: '/services/food-photography' },
      ],
    },
    {
      label: 'Las Vegas',
      href: '/las-vegas',
      children: [
        { label: 'Las Vegas Convention Center', href: '/las-vegas/convention-center' },
        { label: 'Venetian Expo', href: '/las-vegas/venetian-expo' },
        { label: 'Mandalay Bay', href: '/las-vegas/mandalay-bay' },
        { label: 'Caesars Forum', href: '/las-vegas/caesars-forum' },
      ],
    },
    {
      label: 'Events',
      href: '/events',
      children: [
        { label: 'CES headshots', href: '/events/ces-headshots' },
        { label: 'NAB Show headshots', href: '/events/nab-show-headshots' },
        { label: 'SEMA headshots', href: '/events/sema-headshots' },
        { label: 'MJBizCon headshots', href: '/events/mjbizcon-headshots' },
      ],
    },
    { label: 'Portfolio', href: '/portfolio' },
    { label: 'Pricing', href: '/pricing' },
    { label: 'Blog', href: '/blog' },
    { label: 'About', href: '/about' },
  ],
} as const;

export const CLIENTS = [
  'LinkedIn', 'IBM', 'Amazon', 'Dell-EMC', 'SAP', 'Pepsi', 'Toyota', 'Kia',
  'Unilever', 'Saatchi & Saatchi', 'Uber', 'AWS', 'CrowdStrike', 'TravelZoo',
  'Freeman', 'ACFE', 'Enterprise', 'Think', 'AVVO', 'PTTOW!', 'CSCMP',
] as const;

export const TESTIMONIALS = [
  {
    quote: 'We had a line from the start to the end of the expo. We surpassed all our lead generation goals for the event.',
    author: 'Tim',
    role: 'Alliance Executive',
    company: 'AWS',
    event: 'Fal.con (CrowdStrike user conference)',
  },
  {
    quote: 'We had 4 times the number of leads from the previous year.',
    author: 'Tomsen',
    role: 'Partner Marketing Manager',
    company: 'AWS',
  },
  {
    quote: 'The hundreds of people that came through our booth just to get a headshot was so remarkable. The line was always around the corner and people were completely willing to wait.',
    author: 'Carrie Gable',
    role: 'Senior Account Manager',
    company: 'PPD® Biotech',
  },
  {
    quote: 'The instantaneous social sharing was perfect for starting conversations. I think the whole thing was a big hit and everyone is raving about the photos.',
    author: 'Courtney Bryan',
    role: 'Sales Manager',
    company: 'TravelZoo',
  },
  {
    quote: 'The booth was the talk of the convention. We got so much feedback about how at ease you made everyone feel and how great the photos turned out.',
    author: 'Alex Gant',
    role: 'Senior Marketing Manager',
    company: 'EVIDERA',
  },
  {
    quote: 'It was great working with you and you really helped make our presence at the event top-notch. The attendees are thrilled with their headshots!',
    author: 'Kelly Kyer',
    role: 'Global Director, Technology Vertical Marketing',
    company: 'LinkedIn',
  },
] as const;

export const STATS = [
  { value: '250+', label: 'Leads per day', sub: 'captured at your booth' },
  { value: '25%', label: 'Traffic uplift', sub: 'vs. conventional giveaways' },
  { value: '20+', label: 'Years experience', sub: 'professional photography' },
  { value: '700+', label: 'Unique leads', sub: 'over a 2.5-day show' },
] as const;
