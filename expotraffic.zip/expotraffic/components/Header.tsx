import Link from 'next/link';
import { NAV, SITE } from '@/lib/site';

export function Header() {
  return (
    <header className="sticky top-0 z-50 border-b border-ink-900/10 bg-ink-50/80 backdrop-blur-lg">
      <div className="mx-auto flex max-w-[88rem] items-center justify-between px-6 py-4 lg:px-10 lg:py-5">
        <Link href="/" className="group flex items-center gap-3" aria-label="ExpoTraffic — home">
          <span className="font-serif text-2xl font-medium tracking-tight text-ink-900">
            Expo<span className="italic text-amber-500">Traffic</span>
          </span>
        </Link>

        <nav className="hidden items-center gap-8 lg:flex" aria-label="Primary">
          {NAV.primary.slice(0, 5).map((item) => (
            <div key={item.href} className="group relative">
              <Link
                href={item.href}
                className="text-sm font-medium tracking-wide text-ink-700 transition-colors hover:text-ink-900"
              >
                {item.label}
                {'children' in item && item.children && (
                  <span aria-hidden="true" className="ml-1 text-ink-400">↓</span>
                )}
              </Link>
              {'children' in item && item.children && (
                <div className="invisible absolute left-1/2 top-full z-50 w-72 -translate-x-1/2 pt-4 opacity-0 transition-all duration-200 group-hover:visible group-hover:opacity-100">
                  <div className="rounded-lg border border-ink-900/10 bg-ink-50 p-2 shadow-xl shadow-ink-900/5">
                    {item.children.map((c) => (
                      <Link
                        key={c.href}
                        href={c.href}
                        className="block rounded px-3 py-2 text-sm text-ink-700 transition-colors hover:bg-amber-50 hover:text-ink-900"
                      >
                        {c.label}
                      </Link>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </nav>

        <div className="flex items-center gap-4">
          <a
            href={`tel:${SITE.phone}`}
            className="hidden text-sm font-medium text-ink-700 hover:text-ink-900 md:block"
          >
            {SITE.phoneDisplay}
          </a>
          <Link
            href="/contact"
            className="inline-flex items-center gap-2 rounded-full bg-ink-900 px-5 py-2.5 text-sm font-medium text-ink-50 transition-all hover:bg-amber-500"
          >
            Get a quote
            <span aria-hidden="true">→</span>
          </Link>
        </div>
      </div>
    </header>
  );
}
