import Link from 'next/link';
import { SITE } from '@/lib/site';

export function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="border-t border-ink-900/10 bg-ink-800 text-ink-200">
      <div className="mx-auto max-w-[88rem] px-6 py-16 lg:px-10 lg:py-20">
        <div className="grid gap-12 md:grid-cols-2 lg:grid-cols-5">
          <div className="lg:col-span-2">
            <div className="font-serif text-3xl tracking-tight text-ink-50">
              Expo<span className="italic text-amber-400">Traffic</span>
            </div>
            <p className="mt-4 max-w-sm text-sm leading-relaxed text-ink-300">
              Las Vegas tradeshow headshot activation and event photography for Fortune 500 exhibitors, expo producers, and sponsors.
            </p>
            <address className="mt-6 space-y-1 text-sm not-italic text-ink-300">
              <div>{SITE.address.locality}, {SITE.address.region} {SITE.address.postalCode}</div>
              <div>
                <a href={`tel:${SITE.phone}`} className="hover:text-amber-400">{SITE.phoneDisplay}</a>
              </div>
              <div>
                <a href={`mailto:${SITE.email}`} className="hover:text-amber-400">{SITE.email}</a>
              </div>
            </address>
          </div>

          <div>
            <h3 className="mb-4 text-xs font-medium uppercase tracking-widest text-ink-400">Services</h3>
            <ul className="space-y-2 text-sm">
              <li><Link href="/services/tradeshow-headshot-activation" className="hover:text-amber-400">Tradeshow headshot activation</Link></li>
              <li><Link href="/services/conference-headshot-booth" className="hover:text-amber-400">Conference headshot booth</Link></li>
              <li><Link href="/services/sko-sales-kickoff-headshots" className="hover:text-amber-400">SKO headshots</Link></li>
              <li><Link href="/services/corporate-headshots" className="hover:text-amber-400">Corporate headshots</Link></li>
              <li><Link href="/services/event-photography" className="hover:text-amber-400">Event photography</Link></li>
              <li><Link href="/services/food-photography" className="hover:text-amber-400">Food photography</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="mb-4 text-xs font-medium uppercase tracking-widest text-ink-400">Las Vegas venues</h3>
            <ul className="space-y-2 text-sm">
              <li><Link href="/las-vegas/convention-center" className="hover:text-amber-400">Las Vegas Convention Center</Link></li>
              <li><Link href="/las-vegas/venetian-expo" className="hover:text-amber-400">Venetian Expo</Link></li>
              <li><Link href="/las-vegas/mandalay-bay" className="hover:text-amber-400">Mandalay Bay</Link></li>
              <li><Link href="/las-vegas/caesars-forum" className="hover:text-amber-400">Caesars Forum</Link></li>
            </ul>

            <h3 className="mb-4 mt-8 text-xs font-medium uppercase tracking-widest text-ink-400">Major shows</h3>
            <ul className="space-y-2 text-sm">
              <li><Link href="/events/ces-headshots" className="hover:text-amber-400">CES</Link></li>
              <li><Link href="/events/nab-show-headshots" className="hover:text-amber-400">NAB Show</Link></li>
              <li><Link href="/events/sema-headshots" className="hover:text-amber-400">SEMA</Link></li>
              <li><Link href="/events/mjbizcon-headshots" className="hover:text-amber-400">MJBizCon</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="mb-4 text-xs font-medium uppercase tracking-widest text-ink-400">Company</h3>
            <ul className="space-y-2 text-sm">
              <li><Link href="/about" className="hover:text-amber-400">About</Link></li>
              <li><Link href="/portfolio" className="hover:text-amber-400">Portfolio</Link></li>
              <li><Link href="/pricing" className="hover:text-amber-400">Pricing</Link></li>
              <li><Link href="/blog" className="hover:text-amber-400">Blog</Link></li>
              <li><Link href="/contact" className="hover:text-amber-400">Contact</Link></li>
            </ul>
          </div>
        </div>

        <div className="mt-16 flex flex-col justify-between gap-4 border-t border-ink-700 pt-8 text-xs text-ink-400 md:flex-row md:items-center">
          <div>© {year} {SITE.legalName}. All rights reserved.</div>
          <div className="flex gap-6">
            <Link href="/legal/privacy-policy" className="hover:text-amber-400">Privacy Policy</Link>
            <Link href="/legal/terms-of-use" className="hover:text-amber-400">Terms of Use</Link>
            <Link href="/sitemap.xml" className="hover:text-amber-400">Sitemap</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
