import Link from 'next/link';
import { CLIENTS, STATS, TESTIMONIALS } from '@/lib/site';

// ---------- Breadcrumbs ----------
export function Breadcrumbs({ trail }: { trail: { name: string; path: string }[] }) {
  return (
    <nav aria-label="Breadcrumb" className="text-xs uppercase tracking-[0.2em] text-ink-400">
      <ol className="flex flex-wrap items-center gap-2">
        {trail.map((t, i) => (
          <li key={t.path} className="flex items-center gap-2">
            {i > 0 && <span aria-hidden="true">/</span>}
            {i === trail.length - 1 ? (
              <span aria-current="page" className="text-ink-600">{t.name}</span>
            ) : (
              <Link href={t.path} className="hover:text-ink-900">{t.name}</Link>
            )}
          </li>
        ))}
      </ol>
    </nav>
  );
}

// ---------- Client logo marquee ----------
export function ClientMarquee({ heading = 'Trusted by global brands' }: { heading?: string }) {
  const doubled = [...CLIENTS, ...CLIENTS];
  return (
    <section aria-labelledby="clients" className="overflow-hidden border-y border-ink-900/10 bg-ink-100/60 py-10">
      <h2 id="clients" className="text-center text-xs uppercase tracking-[0.3em] text-ink-500">
        {heading}
      </h2>
      <div className="mt-8 flex overflow-hidden">
        <div className="marquee flex shrink-0 items-center gap-16 px-8">
          {doubled.map((c, i) => (
            <span
              key={`${c}-${i}`}
              className="whitespace-nowrap font-serif text-2xl font-medium text-ink-700 md:text-3xl"
            >
              {c}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}

// ---------- Stats row ----------
export function StatsRow() {
  return (
    <section aria-label="Key performance stats" className="border-t border-ink-900/10">
      <div className="mx-auto grid max-w-[88rem] grid-cols-2 divide-x divide-ink-900/10 md:grid-cols-4">
        {STATS.map((s) => (
          <div key={s.label} className="px-6 py-10 text-center md:px-10 md:py-14">
            <div className="font-serif text-5xl font-medium tracking-tight text-ink-900 md:text-6xl">{s.value}</div>
            <div className="mt-3 text-sm font-medium text-ink-700">{s.label}</div>
            <div className="mt-1 text-xs text-ink-500">{s.sub}</div>
          </div>
        ))}
      </div>
    </section>
  );
}

// ---------- Testimonial grid ----------
export function TestimonialGrid({ limit = 6 }: { limit?: number }) {
  const items = TESTIMONIALS.slice(0, limit);
  return (
    <section aria-label="Client testimonials" className="bg-ink-50 py-24 md:py-32">
      <div className="mx-auto max-w-[88rem] px-6 lg:px-10">
        <div className="mb-16 max-w-3xl">
          <div className="text-xs uppercase tracking-[0.3em] text-amber-500">Client stories</div>
          <h2 className="mt-4 font-serif text-display-lg text-ink-900">
            The booth was the <em className="font-serif italic text-amber-500">talk of the convention</em>.
          </h2>
        </div>
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {items.map((t) => (
            <figure key={t.author} className="flex h-full flex-col rounded-2xl border border-ink-900/10 bg-ink-100/40 p-8">
              <svg aria-hidden="true" className="mb-6 h-6 w-6 text-amber-500" viewBox="0 0 24 24" fill="currentColor">
                <path d="M7.17 4.64A6 6 0 0 0 3 10.36V19h6v-8.36H6.5A3.5 3.5 0 0 1 10 7.14V4.64h-2.83Zm9 0A6 6 0 0 0 12 10.36V19h6v-8.36h-2.5A3.5 3.5 0 0 1 19 7.14V4.64h-2.83Z"/>
              </svg>
              <blockquote className="flex-1 font-serif text-lg leading-relaxed text-ink-800">
                &ldquo;{t.quote}&rdquo;
              </blockquote>
              <figcaption className="mt-6 border-t border-ink-900/10 pt-4">
                <div className="text-sm font-medium text-ink-900">{t.author}</div>
                <div className="text-xs text-ink-500">{t.role}{t.company && `, ${t.company}`}</div>
                {'event' in t && t.event && <div className="mt-1 text-xs italic text-ink-400">{t.event}</div>}
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}

// ---------- FAQ accordion (SSR details/summary, works without JS) ----------
export function FAQSection({ items, title = 'Frequently asked questions' }: { items: { q: string; a: string }[]; title?: string }) {
  return (
    <section aria-labelledby="faq-heading" className="border-t border-ink-900/10 py-24 md:py-32">
      <div className="mx-auto grid max-w-[88rem] gap-12 px-6 lg:grid-cols-[1fr_2fr] lg:gap-20 lg:px-10">
        <div>
          <div className="text-xs uppercase tracking-[0.3em] text-amber-500">FAQ</div>
          <h2 id="faq-heading" className="mt-4 font-serif text-display-lg text-ink-900">{title}</h2>
          <p className="mt-6 max-w-md text-ink-600">
            Still have questions? Call Steve directly at{' '}
            <a href="tel:+17029042972" className="underline underline-offset-4 hover:text-amber-500">
              (702) 904-2972
            </a>.
          </p>
        </div>
        <div className="divide-y divide-ink-900/10 border-y border-ink-900/10">
          {items.map((item, i) => (
            <details key={i} className="group py-6">
              <summary className="flex cursor-pointer list-none items-start justify-between gap-4 text-left">
                <h3 className="text-lg font-medium text-ink-900">{item.q}</h3>
                <span
                  aria-hidden="true"
                  className="mt-1 text-2xl text-ink-400 transition-transform group-open:rotate-45"
                >
                  +
                </span>
              </summary>
              <div className="mt-4 max-w-3xl text-ink-600">
                <p>{item.a}</p>
              </div>
            </details>
          ))}
        </div>
      </div>
    </section>
  );
}

// ---------- Final CTA band ----------
export function CTABand({
  headline = 'Ready to own the tradeshow floor?',
  sub = 'Book a call. We\'ll design the headshot activation that turns your booth into the busiest spot on the expo.',
  primary = { label: 'Get a quote', href: '/contact' },
  secondary = { label: 'See pricing', href: '/pricing' },
}: {
  headline?: string;
  sub?: string;
  primary?: { label: string; href: string };
  secondary?: { label: string; href: string };
}) {
  return (
    <section className="relative overflow-hidden bg-ink-900 text-ink-50">
      <div className="mx-auto max-w-[88rem] px-6 py-24 md:py-32 lg:px-10">
        <div className="max-w-3xl">
          <h2 className="font-serif text-display-lg">
            {headline}
          </h2>
          <p className="mt-6 max-w-xl text-lg text-ink-200">{sub}</p>
          <div className="mt-10 flex flex-wrap gap-4">
            <Link
              href={primary.href}
              className="inline-flex items-center gap-2 rounded-full bg-amber-500 px-7 py-3.5 text-sm font-medium text-ink-900 transition-all hover:bg-amber-400"
            >
              {primary.label} <span aria-hidden="true">→</span>
            </Link>
            <Link
              href={secondary.href}
              className="inline-flex items-center gap-2 rounded-full border border-ink-50/30 px-7 py-3.5 text-sm font-medium text-ink-50 transition-all hover:border-ink-50/60"
            >
              {secondary.label}
            </Link>
          </div>
        </div>
      </div>
      <div aria-hidden="true" className="pointer-events-none absolute right-0 top-0 h-full w-1/2 opacity-[0.06]">
        <div className="grid h-full grid-cols-6 gap-4 p-10">
          {Array.from({ length: 48 }).map((_, i) => (
            <div key={i} className="rounded-full bg-amber-500" style={{ opacity: Math.random() }} />
          ))}
        </div>
      </div>
    </section>
  );
}

// ---------- Service card ----------
export function ServiceCard({
  title,
  href,
  description,
  keywords,
  eyebrow,
}: {
  title: string;
  href: string;
  description: string;
  keywords?: string;
  eyebrow?: string;
}) {
  return (
    <Link
      href={href}
      className="group flex h-full flex-col justify-between rounded-2xl border border-ink-900/10 bg-ink-50 p-8 transition-all hover:border-amber-500/50 hover:bg-ink-100/40"
    >
      <div>
        {eyebrow && (
          <div className="mb-3 text-xs uppercase tracking-[0.2em] text-amber-500">{eyebrow}</div>
        )}
        <h3 className="font-serif text-2xl text-ink-900 group-hover:text-amber-600">{title}</h3>
        <p className="mt-3 text-ink-600">{description}</p>
      </div>
      <div className="mt-8 flex items-center justify-between">
        {keywords && <div className="text-xs text-ink-400">{keywords}</div>}
        <span aria-hidden="true" className="text-ink-400 transition-transform group-hover:translate-x-1 group-hover:text-amber-500">
          →
        </span>
      </div>
    </Link>
  );
}

// ---------- Contact form (server action friendly) ----------
export function QuickContactForm({ compact = false }: { compact?: boolean }) {
  return (
    <form
      action="/api/contact"
      method="POST"
      className={compact ? 'space-y-4' : 'space-y-5'}
    >
      <div className="grid gap-4 md:grid-cols-2">
        <label className="block">
          <span className="text-xs font-medium uppercase tracking-wider text-ink-600">Name</span>
          <input
            name="name"
            required
            type="text"
            className="mt-1.5 w-full border-0 border-b border-ink-900/20 bg-transparent py-2 text-ink-900 placeholder-ink-400 focus:border-amber-500 focus:ring-0"
            placeholder="Your name"
          />
        </label>
        <label className="block">
          <span className="text-xs font-medium uppercase tracking-wider text-ink-600">Company</span>
          <input
            name="company"
            type="text"
            className="mt-1.5 w-full border-0 border-b border-ink-900/20 bg-transparent py-2 text-ink-900 placeholder-ink-400 focus:border-amber-500 focus:ring-0"
            placeholder="Your company"
          />
        </label>
      </div>
      <div className="grid gap-4 md:grid-cols-2">
        <label className="block">
          <span className="text-xs font-medium uppercase tracking-wider text-ink-600">Email</span>
          <input
            name="email"
            required
            type="email"
            className="mt-1.5 w-full border-0 border-b border-ink-900/20 bg-transparent py-2 text-ink-900 placeholder-ink-400 focus:border-amber-500 focus:ring-0"
            placeholder="you@company.com"
          />
        </label>
        <label className="block">
          <span className="text-xs font-medium uppercase tracking-wider text-ink-600">Event / Show</span>
          <input
            name="event"
            type="text"
            className="mt-1.5 w-full border-0 border-b border-ink-900/20 bg-transparent py-2 text-ink-900 placeholder-ink-400 focus:border-amber-500 focus:ring-0"
            placeholder="CES 2026, NAB Show, SKO..."
          />
        </label>
      </div>
      <label className="block">
        <span className="text-xs font-medium uppercase tracking-wider text-ink-600">Tell us about your event</span>
        <textarea
          name="message"
          rows={compact ? 3 : 4}
          className="mt-1.5 w-full border-0 border-b border-ink-900/20 bg-transparent py-2 text-ink-900 placeholder-ink-400 focus:border-amber-500 focus:ring-0"
          placeholder="Booth size, days, goals..."
        />
      </label>
      <button
        type="submit"
        className="inline-flex items-center gap-2 rounded-full bg-ink-900 px-7 py-3.5 text-sm font-medium text-ink-50 transition-all hover:bg-amber-500"
      >
        Send request <span aria-hidden="true">→</span>
      </button>
    </form>
  );
}
